#pragma once

class CClientSocket
{
private:
	WSADATA m_WsaData;											//WinSock���
	sockaddr_in m_Address;										//�ڑ�����
	SOCKET m_Socket;											//�\�P�b�g
	char m_szBuffer[1024];										//��M�o�b�t�@

public:
	CClientSocket();
	virtual ~CClientSocket();
	int Connect(const char *pszIpAddress, unsigned int Port);
	int Disconnect();
	int Send(const char *pszBuffer);
	int Receive(CString &strBuffer, unsigned long Timeout);
};
